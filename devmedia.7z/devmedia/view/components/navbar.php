<?php require_once __DIR__ . '/../../config/env.php'; ?>

<header class="navbar">
    <nav>
        <img src="<?= APP_CONSTANTS['APP_URL'] . APP_CONSTANTS['PATH_IMG'] ?>user.jpg" alt="imagem-usuario">
    </nav>
</header>
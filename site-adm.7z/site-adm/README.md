# Problemas para resolver

1. Caminhos de css/img/link
 Se eu mudar de pasta ou mudar o path do projeto, quebra tudo!


# Atv

- Implementar listagem para as telas de artigos, categorias, usuários com dados mockados/fake fornecidos por um array estático.

- Implementar as telas de cadastro e edição para as funcionalidades artigos, categorias, usuários. As telas devem apenas navegar por enquanto, não irá salvar os dados em banco, mas deve usar os dados fake do item anterior. Deve ser considerada a organização dessas telas na estrutura do projeto.


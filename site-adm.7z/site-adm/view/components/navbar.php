<?php require_once "../../config/env.php"; ?>

<!-- navegação -->
<header class="navbar-grid">
    <nav>
        <img src="<?= VARIAVEIS['DIR_IMG'] ?>user.jpg" alt="imagem-usuario">
    </nav>
</header>